import logging
from typing import Any

from fastapi import Header, HTTPException
from pydantic import BaseModel

from app.core.config import settings
from app.core.security import decode_supabase_token


class ErrorResponse(BaseModel):
    error: str


async def require_auth(authorization: str = Header(None)) -> dict[str, Any]:

    if not authorization:
        raise HTTPException(
            status_code=401,
            detail=ErrorResponse(error="Missing Authorization header").model_dump()
        )
    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail=ErrorResponse(error="Invalid Authorization format").model_dump()
        )

    token = authorization.split(" ")[1].strip()

    payload = decode_supabase_token(token)
    if not payload:
        logging.getLogger(__name__).error("Token decode failed or returned None")
        raise HTTPException(
            status_code=401,
            detail=ErrorResponse(error="Invalid or expired token").model_dump()
        )



    user_id = payload.get("sub")
    if not user_id:
        logging.getLogger(__name__).error(f"Token missing user ID. Payload keys: {payload.keys()}")
        raise HTTPException(
            status_code=401,
            detail=ErrorResponse(error="Token missing user ID").model_dump()
        )
    issuer = payload.get("iss", "").rstrip("/")

    expected_base = settings.SUPABASE_URL.rstrip("/")

    # Normalize issuer for check (handle trailing slash mismatch)
    if not issuer.startswith(expected_base):
        logging.getLogger(__name__).error(f"Invalid issuer: {issuer}. Expected startswith: {expected_base}")
        raise HTTPException(
            status_code=401,
            detail=ErrorResponse(
                error=f"Invalid issuer. Expected startswith {expected_base}, got {issuer}"
            ).model_dump()
        )

    # Authentication success
    return {"user_id": user_id}


async def require_auth_optional(
    authorization: str | None = Header(None)
) -> dict[str, Any] | None:
    """
    Optional version.
    Returns:
      - dict(user_id=...) if valid
      - None if missing/invalid
    """

    if not authorization:
        return None

    try:
        return await require_auth(authorization)
    except HTTPException:
        return None
