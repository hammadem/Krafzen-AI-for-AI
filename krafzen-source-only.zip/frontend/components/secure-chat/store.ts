
import { create } from 'zustand'
import { generateSessionId } from '@/lib/security/crypto'
import type { CompliancePayload } from '@/lib/api/chat'

export interface MessageFeedback {
    reaction: 'up' | 'down'
    reason?: string
}

export interface Message {
    id: string
    role: 'user' | 'assistant' | 'system'
    content: string // In a real zero-leak env, this could be encryptedString
    imageUrl?: string
    timestamp: number
    metadata?: Record<string, unknown>
    feedback?: MessageFeedback
    compliance?: CompliancePayload
}

export interface ChatSession {
    id: string
    title: string
    messages: Message[]
    createdAt: number
    lastActive: number
    isBackground: boolean // Logic to handle background socket/RTC connections
    isGenerating?: boolean // Per-session loading state
    hasMore?: boolean // Cursor pagination: whether older messages exist
    nextCursor?: string | null // Cursor message ID or timestamp for loading older messages
}

interface ChatState {
    sessions: Record<string, ChatSession>
    activeSessionId: string | null

    // Actions
    createSession: (title?: string) => string
    switchSession: (sessionId: string) => void
    addMessage: (sessionId: string, message: Omit<Message, 'timestamp' | 'id'> & { id?: string }) => void
    deleteSession: (sessionId: string) => void
    updateSessionTitle: (sessionId: string, title: string) => void
    setGenerating: (sessionId: string, isGenerating: boolean) => void

    // Cleanup
    clearAllSessions: () => void

    // Persist Hydration & Pagination
    setSessions: (sessions: Record<string, ChatSession>) => void
    appendMessages: (sessionId: string, messages: Message[]) => void
    setSessionMessages: (sessionId: string, messages: Message[], hasMore?: boolean, nextCursor?: string | null) => void
    prependMessages: (sessionId: string, messages: Message[], hasMore?: boolean, nextCursor?: string | null) => void
    setMessageFeedback: (sessionId: string, messageId: string, feedback: MessageFeedback) => void
}

export const useChatStore = create<ChatState>((set, get) => ({
    sessions: {},
    activeSessionId: null,

    createSession: (title) => {
        const id = generateSessionId()
        const newSession: ChatSession = {
            id,
            title: title || `New Session ${Object.keys(get().sessions).length + 1}`,
            messages: [],
            createdAt: Date.now(),
            lastActive: Date.now(),
            isBackground: false
        }

        set((state) => ({
            sessions: { ...state.sessions, [id]: newSession },
            activeSessionId: id
        }))
        return id
    },

    switchSession: (sessionId) => {
        set((state) => {
            // Mark old session as background?
            // In a real implementation with WebSockets, we might pause the socket for the old session
            // or keep it alive in background.
            return { activeSessionId: sessionId }
        })
    },

    addMessage: (sessionId, message) => {
        const start = Date.now()
        set((state) => {
            const session = state.sessions[sessionId]
            if (!session) return state

            const updatedSession = {
                ...session,
                lastActive: Date.now(),
                messages: [
                    ...session.messages,
                    {
                        ...message,
                        id: message.id ?? generateSessionId(),
                        timestamp: Date.now()
                    }
                ]
            }

            return {
                sessions: {
                    ...state.sessions,
                    [sessionId]: updatedSession
                }
            }
        })
    },

    deleteSession: (sessionId) => {
        set((state) => {
            const { [sessionId]: deleted, ...remaining } = state.sessions
            const newActive = state.activeSessionId === sessionId
                ? (Object.keys(remaining)[0] || null)
                : state.activeSessionId

            return {
                sessions: remaining,
                activeSessionId: newActive
            }
        })
    },

    updateSessionTitle: (sessionId, title) => {
        set((state) => {
            const session = state.sessions[sessionId]
            if (!session) return state

            return {
                sessions: {
                    ...state.sessions,
                    [sessionId]: { ...session, title }
                }
            }
        })
    },

    setGenerating: (sessionId, isGenerating) => {
        set((state) => {
            const session = state.sessions[sessionId]
            if (!session) return state

            return {
                sessions: {
                    ...state.sessions,
                    [sessionId]: { ...session, isGenerating }
                }
            }
        })
    },

    clearAllSessions: () => set({ sessions: {}, activeSessionId: null }),

    // Persist Actions
    setSessions: (sessions) => set({ sessions, activeSessionId: Object.keys(sessions)[0] || null }),
    appendMessages: (sessionId, messages) => {
        set((state) => {
            const session = state.sessions[sessionId];
            if (!session) return state;
            return {
                sessions: {
                    ...state.sessions,
                    [sessionId]: {
                        ...session,
                        messages: [...session.messages, ...messages]
                    }
                }
            }
        })
    },

    setSessionMessages: (sessionId, messages, hasMore = false, nextCursor = null) => {
        set((state) => {
            const session = state.sessions[sessionId];
            if (!session) return state;
            return {
                sessions: {
                    ...state.sessions,
                    [sessionId]: {
                        ...session,
                        messages,
                        hasMore,
                        nextCursor
                    }
                }
            }
        })
    },

    prependMessages: (sessionId, messages, hasMore = false, nextCursor = null) => {
        set((state) => {
            const session = state.sessions[sessionId];
            if (!session) return state;
            // Avoid duplicate message insertion if any
            const existingIds = new Set(session.messages.map((m) => m.id));
            const uniqueNewMessages = messages.filter((m) => !existingIds.has(m.id));
            return {
                sessions: {
                    ...state.sessions,
                    [sessionId]: {
                        ...session,
                        messages: [...uniqueNewMessages, ...session.messages],
                        hasMore,
                        nextCursor
                    }
                }
            }
        })
    },

    setMessageFeedback: (sessionId, messageId, feedback) => {
        set((state) => {
            const session = state.sessions[sessionId];
            if (!session) return state;
            const messages = session.messages.map((m) =>
                m.id === messageId ? { ...m, feedback } : m
            );
            return {
                sessions: {
                    ...state.sessions,
                    [sessionId]: { ...session, messages }
                }
            };
        })
    }
}))
