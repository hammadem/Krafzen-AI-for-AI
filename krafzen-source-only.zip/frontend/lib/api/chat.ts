import { getApiBaseUrl } from "./utils";

export interface ComplianceViolation {
    rule_id: string;
    message: string;
    suggestion: string;
}

/** USA IRC baseline screening payload from POST /chat/generate when jurisdiction is US_IRC_BASELINE */
export interface CompliancePayload {
    jurisdiction_id: string;
    jurisdiction_label: string;
    score_percent: number | null;
    status_label: string;
    passed_rules: number;
    applicable_rules: number;
    violations: ComplianceViolation[];
    suggestions: string[];
    disclaimer: string;
    layout_extract?: Record<string, unknown>;
}

export interface ChatResponse {
    session_id: string;
    message_id?: string; // ID of created assistant message (for feedback)
    original_prompt: string;
    ollama_response: string;
    validated_response: string;
    image_url: string;
    remaining_minutes?: number;
    compliance?: CompliancePayload | null;
}

export type ChatJurisdiction = "standard" | "US_IRC_BASELINE";

export async function sendChatMessage(
    message: string,
    history: { role: string, content: string, imageUrl?: string }[] = [],
    token?: string,
    sessionId?: string,
    jurisdiction?: ChatJurisdiction,
    previousImageUrl?: string
): Promise<ChatResponse> {
    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const body: Record<string, unknown> = { message, history };
    if (sessionId) body.session_id = sessionId;
    if (jurisdiction === "US_IRC_BASELINE") body.jurisdiction = "US_IRC_BASELINE";
    if (previousImageUrl) body.previous_image_url = previousImageUrl;

    const response = await fetch(`${getApiBaseUrl()}/api/v1/chat/generate`, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const detail = errorData?.detail;
        const message = typeof detail === 'string'
            ? detail
            : Array.isArray(detail) && detail[0]?.msg
                ? detail[0].msg
                : response.status === 402
                    ? 'No chat requests remaining. Subscribe to a plan to continue, or wait for your billing cycle to renew.'
                    : 'Failed to generate response';
        throw new Error(message);
    }

    return response.json();
}

export async function createChatSession(title: string = "New Chat", token: string) {
    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };
    const res = await fetch(`${getApiBaseUrl()}/api/v1/chat/session`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ title })
    });
    if (!res.ok) throw new Error("Failed to create session");
    return res.json();
}

export async function fetchChatHistory(token: string): Promise<Array<{ id: string; title?: string; created_at: string; updated_at: string }>> {
    const headers = { 'Authorization': `Bearer ${token}` };
    const url = `${getApiBaseUrl()}/api/v1/chat/history`;
    const res = await fetch(url, { headers });
    if (!res.ok) {
        // 401: token invalid/expired or backend auth mismatch — return empty so chat still works with a new session
        if (res.status === 401) {
            if (typeof window !== "undefined") {
                console.warn("Chat history: unauthorized (401). Using empty history. Check backend Supabase JWT config if this persists.");
            }
            return [];
        }
        let detail = `Failed to fetch history (${res.status})`;
        try {
            const body = await res.json();
            if (body?.detail) {
                const d = body.detail;
                detail += typeof d === 'string' ? `: ${d}` : `: ${d?.error ?? JSON.stringify(d)}`;
            }
        } catch {
            try {
                detail += `: ${await res.text()}`;
            } catch {
                // ignore
            }
        }
        throw new Error(detail);
    }
    const data = await res.json();
    return Array.isArray(data) ? data : [];
}

export interface SessionMessageFromApi {
    id: string;
    role: string;
    content?: string;
    image_url?: string;
    created_at: string;
    feedback?: { reaction: 'up' | 'down'; reason?: string };
    compliance?: CompliancePayload | null;
}

export interface PaginatedSessionMessages {
    messages: SessionMessageFromApi[];
    has_more: boolean;
    next_cursor?: string | null;
}

export async function fetchSessionMessages(
    sessionId: string,
    token: string,
    limit: number = 30,
    before?: string
): Promise<PaginatedSessionMessages> {
    const headers = { 'Authorization': `Bearer ${token}` };
    let url = `${getApiBaseUrl()}/api/v1/chat/history/${sessionId}?limit=${limit}`;
    if (before) {
        url += `&before=${encodeURIComponent(before)}`;
    }
    const res = await fetch(url, { headers });
    if (!res.ok) throw new Error("Failed to fetch messages");
    const data = await res.json();
    if (Array.isArray(data)) {
        return { messages: data, has_more: false, next_cursor: null };
    }
    return data;
}

export async function submitMessageFeedback(
    messageId: string,
    reaction: 'up' | 'down',
    reason: string | undefined,
    token: string
): Promise<void> {
    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
    };
    const res = await fetch(`${getApiBaseUrl()}/api/v1/chat/message/${messageId}/feedback`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ reaction, reason: reason || null }),
    });
    if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.detail || 'Failed to submit feedback');
    }
}

export async function updateChatSessionTitle(sessionId: string, title: string, token: string) {
    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };
    const res = await fetch(`${getApiBaseUrl()}/api/v1/chat/history/${sessionId}/title`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ title })
    });
    if (!res.ok) throw new Error("Failed to update session title");
    return res.json();
}

export async function deleteChatSession(sessionId: string, token: string) {
    const headers = { 'Authorization': `Bearer ${token}` };
    const res = await fetch(`${getApiBaseUrl()}/api/v1/chat/history/${sessionId}`, {
        method: 'DELETE',
        headers
    });
    if (!res.ok) throw new Error("Failed to delete session");
    return res.json();
}

export const downloadDxf = async (imageUrl: string, prompt?: string, token?: string) => {
    try {
        const headers: Record<string, string> = {
            'Content-Type': 'application/json',
        };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const response = await fetch(`${getApiBaseUrl()}/api/v1/chat/dxf`, {
            method: 'POST',
            headers,
            body: JSON.stringify({ image_url: imageUrl, prompt }),
        });

        if (!response.ok) {
            let errorMessage = response.statusText;
            try {
                // Only try to parse JSON for error responses
                const errorData = await response.json();
                if (errorData.detail) {
                    errorMessage = errorData.detail;
                }
            } catch (e) {
                // Ignore json parse error, use statusText
            }
            throw new Error(`Failed to download DXF: ${errorMessage}`);
        }

        // For successful responses, return the binary blob directly
        return await response.blob();
    } catch (error) {
        console.error('Error downloading DXF:', error);
        throw error;
    }
};

/** DWG via ODA+Xvfb can take 1–3 minutes on cold start; avoid short client/proxy timeouts. */
const DESIGN_FILE_FETCH_MS = 5 * 60 * 1000;

export const downloadDesignFile = async (
    imageUrl: string,
    fileType: 'dxf' | 'dwg',
    prompt?: string,
    token?: string,
    signal?: AbortSignal
) => {
    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const timeoutController = new AbortController();
    const timeoutId = setTimeout(() => timeoutController.abort(), DESIGN_FILE_FETCH_MS);
    const onExternalAbort = () => timeoutController.abort();
    signal?.addEventListener('abort', onExternalAbort);

    let response: Response;
    try {
        response = await fetch(`${getApiBaseUrl()}/api/v1/chat/design-file`, {
            method: 'POST',
            headers,
            body: JSON.stringify({ image_url: imageUrl, prompt, file_type: fileType }),
            signal: timeoutController.signal,
        });
    } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
            if (signal?.aborted) {
                throw new Error('Download cancelled.');
            }
            throw new Error(
                `Generating ${fileType.toUpperCase()} took too long. Please wait a minute and try once — do not click repeatedly.`
            );
        }
        if (err instanceof TypeError) {
            throw new Error(
                `Could not reach the server while generating ${fileType.toUpperCase()}. ` +
                    'Wait for the current attempt to finish (can take 1–2 minutes) and try once.'
            );
        }
        throw err;
    } finally {
        clearTimeout(timeoutId);
        signal?.removeEventListener('abort', onExternalAbort);
    }

    if (!response.ok) {
        const text = await response.text();
        let errorMessage = (response.statusText || "").trim() || `HTTP ${response.status}`;
        try {
            const errorData = JSON.parse(text) as {
                detail?: string | Array<{ msg?: string }> | { msg?: string };
                message?: string;
            };
            const d = errorData?.detail;
            const m = errorData?.message;
            if (typeof d === "string" && d.trim()) {
                errorMessage = d.trim();
            } else if (typeof m === "string" && m.trim()) {
                errorMessage = m.trim();
            } else if (Array.isArray(d) && d.length > 0) {
                errorMessage = d
                    .map((x) => (typeof x?.msg === "string" ? x.msg : JSON.stringify(x)))
                    .join("; ");
            } else if (d && typeof d === "object" && "msg" in d && typeof (d as { msg?: string }).msg === "string") {
                errorMessage = (d as { msg: string }).msg;
            }
        } catch {
            if (text.trim()) {
                errorMessage = text.trim().slice(0, 800);
            }
        }
        throw new Error(`Failed to download ${fileType.toUpperCase()}: ${errorMessage}`);
    }

    return await response.blob();
};

export async function transcribeAudio(audioBlob: Blob, token?: string): Promise<string> {
    const formData = new FormData();
    const extension = audioBlob.type.includes('mp4') ? 'mp4' : 'webm';
    formData.append('file', audioBlob, `rec.${extension}`);

    const headers: Record<string, string> = {};
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${getApiBaseUrl()}/api/v1/transcribe`, {
        method: 'POST',
        headers,
        body: formData,
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Transcription failed');
    }

    const data = await response.json();
    return data.text;
}
